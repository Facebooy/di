import 'package:flutter/material.dart';
class OrdersScreen extends StatelessWidget { const OrdersScreen({super.key}); @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('My Orders')),body:const Center(child:Text('Login to view your orders.'))); }
