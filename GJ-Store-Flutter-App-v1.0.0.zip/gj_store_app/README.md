# GJ Store Flutter App

Starter Android/iOS Flutter client for the GJ Plugin Store.

## Setup
1. Install Flutter SDK.
2. Run `flutter pub get`.
3. Open `lib/config.dart` and confirm `baseUrl`.
4. Run `flutter run`.

## Important
The app expects the GJ Plugin Store REST API under `/wp-json/gjps/v1`.
The exact response/auth schema should be verified against the installed plugin before enabling login, checkout, payment submission, licenses, downloads and push notifications.

This starter intentionally does not invent payment or authentication request formats. Wire those endpoints after confirming the plugin's actual API responses.
